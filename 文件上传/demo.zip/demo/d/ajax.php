<?php
	header('Access-Control-Allow-Origin:http://www.c.com');
	echo "hello";
?>